# kuanjen.xyz

Static portfolio site (plain HTML + CSS, no build step). Rebuilt from the old WordPress/Semplice site.

- `index.html` – Work (home)
- `about/index.html` – About
- `style.css`, `fonts/`, `img/` – design, self-hosted fonts, optimized images

## Edit
Change text in the HTML files, swap images in `img/`, commit, push. Cloudflare redeploys automatically.

## Deploy (Cloudflare Pages)
Build command: leave empty. Output directory: `/` (root).
